ESX = nil

local garageLocations = {
    {x = -43.0, y = -1097.0, z = 26.4},  -- Exemple de coordonnées de garage
}

-- Initialisation de ESX
Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(0)
    end
end)

-- Afficher un texte 3D à un emplacement
function DrawText3D(x, y, z, text)
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    AddTextComponentString(text)
    DrawText(_World3dToScreen2d(x, y, z))
end

-- Boucle de vérification de l'interaction
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local playerPed = PlayerPedId()
        local playerCoords = GetEntityCoords(playerPed)

        for _, loc in pairs(garageLocations) do
            local distance = GetDistanceBetweenCoords(playerCoords, loc.x, loc.y, loc.z, true)
            
            if distance < 5.0 then
                DrawText3D(loc.x, loc.y, loc.z + 1.0, "[E] Accéder au garage")
                
                if distance < 2.0 and IsControlJustPressed(0, 38) then -- Touche "E"
                    TriggerEvent('garage:openMenu')
                end
            end
        end
    end
end)

-- Ouvrir un menu pour gérer les véhicules
RegisterNetEvent('garage:openMenu')
AddEventHandler('garage:openMenu', function()
    local elements = {
        {label = "Garer le véhicule", value = "park_vehicle"},
        {label = "Récupérer un véhicule", value = "retrieve_vehicle"},
    }

    -- Menu d'interaction
    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'garage_menu',
    {
        title    = 'Garage',
        align    = 'top-left',
        elements = elements
    }, function(data, menu)
        if data.current.value == "park_vehicle" then
            TriggerServerEvent('garage:parkVehicle')
        elseif data.current.value == "retrieve_vehicle" then
            TriggerServerEvent('garage:retrieveVehicle')
        end
    end, function(data, menu)
        menu.close()
    end)
end)
