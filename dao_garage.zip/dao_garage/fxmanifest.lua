fx_version 'cerulean'
game 'gta5'

author 'DAO'
description 'DAO Garage'
version '1.0.0'

dependency 'es_extended'

client_script 'client.lua'
server_script 'server.lua'

shared_script '@es_extended/locale.lua'