CREATE TABLE `player_vehicles` (
    `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `owner` VARCHAR(50) NOT NULL, -- Le steamID ou identifier du joueur
    `vehicle_plate` VARCHAR(8) NOT NULL, -- La plaque du véhicule
    `vehicle_model` VARCHAR(50) NOT NULL, -- Le modèle du véhicule
    `garage_x` FLOAT NOT NULL, -- Coordonnées du garage où le véhicule est garé
    `garage_y` FLOAT NOT NULL,
    `garage_z` FLOAT NOT NULL
);