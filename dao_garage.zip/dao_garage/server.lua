ESX = nil
local MySQL = require('mysql-async')

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

-- Fonction pour garer un véhicule
RegisterNetEvent('garage:parkVehicle')
AddEventHandler('garage:parkVehicle', function()
    local xPlayer = ESX.GetPlayerFromId(source)
    local playerPed = GetPlayerPed(source)
    local vehicle = GetVehiclePedIsIn(playerPed, false)
    local plate = GetVehicleNumberPlateText(vehicle)

    if vehicle then
        local coords = GetEntityCoords(vehicle)
        local model = GetEntityModel(vehicle)

        -- Sauvegarder dans la base de données
        MySQL.Async.execute('INSERT INTO player_vehicles (owner, vehicle_plate, vehicle_model, garage_x, garage_y, garage_z) VALUES (@owner, @plate, @model, @x, @y, @z)', {
            ['@owner'] = xPlayer.identifier,
            ['@plate'] = plate,
            ['@model'] = model,
            ['@x'] = coords.x,
            ['@y'] = coords.y,
            ['@z'] = coords.z
        }, function(rowsChanged)
            TriggerClientEvent('esx:showNotification', source, 'Véhicule garé avec succès!')
        end)

        -- Supprimer le véhicule du monde
        SetEntityAsMissionEntity(vehicle, true, true)
        DeleteVehicle(vehicle)
    else
        TriggerClientEvent('esx:showNotification', source, 'Vous n\'êtes pas dans un véhicule.')
    end
end)

-- Fonction pour récupérer un véhicule
RegisterNetEvent('garage:retrieveVehicle')
AddEventHandler('garage:retrieveVehicle', function()
    local xPlayer = ESX.GetPlayerFromId(source)

    -- Rechercher les véhicules garés du joueur
    MySQL.Async.fetchAll('SELECT * FROM player_vehicles WHERE owner = @owner', {
        ['@owner'] = xPlayer.identifier
    }, function(result)
        if #result > 0 then
            local vehicleData = result[1] -- On prend le premier véhicule garé
            local plate = vehicleData.vehicle_plate
            local model = vehicleData.vehicle_model
            local coords = vector3(vehicleData.garage_x, vehicleData.garage_y, vehicleData.garage_z)

            -- Créer le véhicule à l'endroit garé
            RequestModel(model)

            while not HasModelLoaded(model) do
                Citizen.Wait(500)
            end

            local veh = CreateVehicle(model, coords.x, coords.y, coords.z, 0.0, true, false)
            SetEntityAsMissionEntity(veh, true, true)
            TriggerClientEvent('esx:showNotification', source, 'Véhicule récupéré !')
        else
            TriggerClientEvent('esx:showNotification', source, 'Aucun véhicule garé trouvé.')
        end
    end)
end)
